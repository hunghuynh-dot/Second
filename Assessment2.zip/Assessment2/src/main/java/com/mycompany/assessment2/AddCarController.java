package com.mycompany.assessment2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.time.Year; // Correct import for Year
import java.util.ResourceBundle;

public class AddCarController implements Initializable {

    @FXML private TextField txtCarID;
    @FXML private TextField txtBrand;
    @FXML private TextField txtModel;
    @FXML private TextField txtYear;
    @FXML private TextField txtPrice;
    @FXML private RadioButton radioNew;
    @FXML private RadioButton radioUsed;
    @FXML private ToggleGroup categoryGroup; // Make sure this fx:id is set in your FXML for the ToggleGroup
    @FXML private Button btnSubmit;
    @FXML private Button btnReset;
    @FXML private Button btnCancel;
    @FXML private Label lblMessage;

    private final Year currentYear = Year.now();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Set focus to the first text field
        txtCarID.requestFocus();

        // Clear any previous messages
        lblMessage.setText("");
        lblMessage.setStyle("-fx-text-fill: black;"); // Default message color

        // Set default radio button selection
        radioNew.setSelected(true);
    }

    @FXML
    private void handleSubmit(ActionEvent event) {
        // Clear previous message
        lblMessage.setText("");
        lblMessage.setStyle("-fx-text-fill: red;"); // Default to error color for messages

        // Validate all inputs
        if (!validateInputs()) {
            return; // Validation failed, message already set
        }

        try {
            // Parse inputs (validation already ensured they are parseable)
            int carID = Integer.parseInt(txtCarID.getText().trim());
            String brand = txtBrand.getText().trim();
            String model = txtModel.getText().trim();
            int year = Integer.parseInt(txtYear.getText().trim());
            int price = Integer.parseInt(txtPrice.getText().trim());
            String category = radioNew.isSelected() ? "New" : "Used";

            // Check if car ID already exists (using the static method from MainMenuController)
            if (MainMenuController.findCar(carID) != -1) {
                lblMessage.setText("Error: Car ID " + carID + " already exists!");
                txtCarID.selectAll(); // Select text for easy re-entry
                txtCarID.requestFocus();
                return;
            }

            // Create new car object
            Car newCar = new Car(carID, brand, model, year, price, category);

            // Add to the list (using the static method from MainMenuController)
            MainMenuController.addCar(newCar);

            // Show success message
            lblMessage.setStyle("-fx-text-fill: green;");
            lblMessage.setText("Car added successfully!\n" + newCar.toString()); // Assuming Car.toString() is well-formatted

            // Clear all fields and set focus back to first field for next entry
            clearAllFields();
            txtCarID.requestFocus();

        } catch (NumberFormatException e) {
            // This catch block might be redundant if validateInputs is thorough,
            // but good as a fallback.
            lblMessage.setText("Error: Invalid number format. Please check Car ID, Year, or Price!");
        } catch (Exception e) {
            // Catch any other unexpected errors
            lblMessage.setText("An unexpected error occurred: " + e.getMessage());
            e.printStackTrace(); // Log the full error for debugging
        }
    }

    @FXML
    private void handleReset(ActionEvent event) {
        clearAllFields();
        lblMessage.setText(""); // Clear any previous messages
        lblMessage.setStyle("-fx-text-fill: black;"); // Reset message color
        txtCarID.requestFocus();
    }

    @FXML
    private void handleCancel(ActionEvent event) {
        try {
            // Use relative path for loading FXML from the same package
            FXMLLoader loader = new FXMLLoader(getClass().getResource("mainMenu.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Car Management System"); // Reset title to main menu title
            stage.show();
        } catch (IOException e) {
            showAlert(Alert.AlertType.ERROR, "Navigation Error", "Could not return to main menu: " + e.getMessage());
            e.printStackTrace(); // Print stack trace for debugging
        }
    }

    private boolean validateInputs() {
        // Validate Car ID
        String carIDText = txtCarID.getText().trim();
        if (carIDText.isEmpty()) {
            lblMessage.setText("Error: Car ID cannot be blank!");
            txtCarID.requestFocus();
            return false;
        }
        if (!isStringNumeric(carIDText)) {
            lblMessage.setText("Error: Car ID must be numeric!");
            txtCarID.selectAll();
            txtCarID.requestFocus();
            return false;
        }
        if (carIDText.length() != 3) {
            lblMessage.setText("Error: Car ID must be a 3-digit number!");
            txtCarID.selectAll();
            txtCarID.requestFocus();
            return false;
        }

        // Validate Brand
        String brand = txtBrand.getText().trim();
        if (brand.isEmpty()) {
            lblMessage.setText("Error: Brand cannot be blank!");
            txtBrand.requestFocus();
            return false;
        }

        // Validate Model
        String model = txtModel.getText().trim();
        if (model.isEmpty()) {
            lblMessage.setText("Error: Model cannot be blank!");
            txtModel.requestFocus();
            return false;
        }

        // Validate Year
        String yearText = txtYear.getText().trim();
        if (yearText.isEmpty()) {
            lblMessage.setText("Error: Year cannot be blank!");
            txtYear.requestFocus();
            return false;
        }
        if (!isStringNumeric(yearText)) {
            lblMessage.setText("Error: Year must be numeric!");
            txtYear.selectAll();
            txtYear.requestFocus();
            return false;
        }
        if (yearText.length() != 4) {
            lblMessage.setText("Error: Year must be a 4-digit number!");
            txtYear.selectAll();
            txtYear.requestFocus();
            return false;
        }

        int year = Integer.parseInt(yearText); // Safe to parse after validation
        if (year < 1886 || year > currentYear.getValue() + 1) { // Basic sanity check for car year, allow next year for upcoming models
            lblMessage.setText("Error: Year must be between 1886 and " + (currentYear.getValue() + 1) + "!");
            txtYear.selectAll();
            txtYear.requestFocus();
            return false;
        }

        // Validate Price
        String priceText = txtPrice.getText().trim();
        if (priceText.isEmpty()) {
            lblMessage.setText("Error: Price cannot be blank!");
            txtPrice.requestFocus();
            return false;
        }
        if (!isStringNumeric(priceText)) { // Also allow for decimal if needed, but current code assumes integer
            lblMessage.setText("Error: Price must be numeric!");
            txtPrice.selectAll();
            txtPrice.requestFocus();
            return false;
        }

        int price = Integer.parseInt(priceText); // Safe to parse
        if (price <= 0) {
            lblMessage.setText("Error: Price must be greater than zero!");
            txtPrice.selectAll();
            txtPrice.requestFocus();
            return false;
        }

        // Validate Category (radio button selection)
        if (categoryGroup.getSelectedToggle() == null) { // Check if any radio button in the group is selected
            lblMessage.setText("Error: Please select a category (New or Used)!");
            // Potentially focus radioNew or some other relevant control
            return false;
        }

        lblMessage.setText(""); // Clear message if all validations pass
        lblMessage.setStyle("-fx-text-fill: black;");
        return true;
    }

    private void clearAllFields() {
        txtCarID.clear();
        txtBrand.clear();
        txtModel.clear();
        txtYear.clear();
        txtPrice.clear();
        if (categoryGroup != null && radioNew != null) { // Ensure radioNew is not null
            radioNew.setSelected(true); // Default to 'New'
        }
        // txtCarID.requestFocus(); // Done in handleSubmit and handleReset
    }

    // Check if string is numeric (can be enhanced to check for positive integers etc.)
    private boolean isStringNumeric(String str) {
        if (str == null || str.isEmpty()) {
            return false;
        }
        for (char c : str.toCharArray()) {
            if (!Character.isDigit(c)) {
                return false;
            }
        }
        return true;
    }

    // Utility method to show alerts (already present, good)
    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}