package com.mycompany.assessment2;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;

/**
 * JavaFX Car Registration Application
 * COIT11134 Object-Oriented Programming - Assignment 2
 * 
 * Main application class that launches the JavaFX GUI application
 * for car registration management.
 * 
 * @author Ngoc Hung Huynh - 12284303
 */
public class App extends Application {

    private static Scene scene;
    private static Stage primaryStage;

    @Override
    public void start(Stage stage) throws IOException {
        primaryStage = stage;
        
        // Load the main menu FXML file
        scene = new Scene(loadFXML("mainMenu"), 640, 480);
        
        // Set up the primary stage
        stage.setTitle("Car Registration System");
        stage.setScene(scene);
        stage.setResizable(false); // Optional: prevent window resizing
        
        // Show the application window
        stage.show();
        
        // Load existing car data when application starts
        CarManager.getInstance().loadCarsFromFile();
    }

    /**
     * Changes the current scene root to the specified FXML file
     * @param fxml the name of the FXML file (without .fxml extension)
     * @throws IOException if the FXML file cannot be loaded
     */
    static void setRoot(String fxml) throws IOException {
        scene.setRoot(loadFXML(fxml));
    }

    /**
     * Loads an FXML file and returns the Parent node
     * @param fxml the name of the FXML file (without .fxml extension)
     * @return Parent node from the FXML file
     * @throws IOException if the FXML file cannot be loaded
     */
// In App.java
private static Parent loadFXML(String fxml) throws IOException {
    // The resource path is now just the FXML file name.
    // App.class.getResource() will look for it in the same package
    // path as App.class, which is com/mycompany/assessment2/
    String resourcePath = fxml + ".fxml";
    java.net.URL fxmlUrl = App.class.getResource(resourcePath);

    if (fxmlUrl == null) {
        throw new IOException("Cannot find FXML resource: " + resourcePath +
                              ". Expected in: src/main/resources/com/mycompany/assessment2/" + resourcePath);
    }

    FXMLLoader fxmlLoader = new FXMLLoader(fxmlUrl);
    return fxmlLoader.load();
}
    /**
     * Gets the primary stage of the application
     * @return the primary Stage
     */
    public static Stage getPrimaryStage() {
        return primaryStage;
    }

    /**
     * Gets the current scene
     * @return the current Scene
     */
    public static Scene getScene() {
        return scene;
    }

    /**
     * Main method - entry point of the application
     * @param args command line arguments
     */
    public static void main(String[] args) {
        System.setProperty("prism.font", "Arial");
        System.setProperty("prism.text", "Arial");
        launch(args);
    }
}