/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assessment2;


public class Car {
    
    private int carID;
    private String brand;
    private String model;
    private int year;
    private int price;
    private String category;
    
    //OVerloaded constructor
    public Car (int carID, String brand, String model, int year, int price, String category){
        this.carID = carID;
        this.brand = brand;
        this.model = model;
        this.year = year;
        this.price = price;
        this.category = category;
    }
     // Getters and setters
    public int getCarID() {
        return carID;
    }

    public void setCarID(int carID) {
        this.carID = carID;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    /**
     * Override toString method to display car details
     * @return String representation of the car object
     */
    @Override
    public String toString() {
        return "Car ID: " + carID + 
               "\nBrand: " + brand + 
               "\nModel: " + model + 
               "\nYear: " + year + 
               "\nPrice: $" + price + 
               "\nCategory: " + category;
    }
    
}
