package com.mycompany.assessment2;

import java.io.*;
import java.time.Year;
import java.util.ArrayList;

/**
 * Singleton Car Manager class for handling car operations
 * COIT11134 Object-Oriented Programming - Assignment 2
 * 
 * @author Ngoc Hung Huynh - 12284303
 */
public class CarManager {
    private static CarManager instance;
    private ArrayList<Car> carList = new ArrayList<>();
    private final Year currentYear = Year.now();
    private final String DATA_FILE = "cars_data.txt";
    
    // Private constructor for singleton pattern
    private CarManager() {
        // Initialize empty car list
    }
    
    // Singleton getInstance method
    public static CarManager getInstance() {
        if (instance == null) {
            instance = new CarManager();
        }
        return instance;
    }
    
    // Validation methods from Assignment 1
    public boolean isStringNumeric(String str) {       
        if (str == null || str.isEmpty()) {
            return false;
        }
        for (int i = 0; i < str.length(); i++) {
            if (!Character.isDigit(str.charAt(i))) {
                return false;
            }
        }   
        return true;
    }
    
    public boolean isYearValid(String theYearStr) {       
        if (isStringNumeric(theYearStr) && theYearStr.length() == 4){
            int year = Integer.parseInt(theYearStr);  
            if (year > currentYear.getValue()){
                return false;            
            }            
            return true;
        }
        return false;
    }
    
    public boolean isPriceValid(String thePrice){
        if (!isStringNumeric(thePrice)){
            return false;
        }
        int price = Integer.parseInt(thePrice);
        return price > 0;
    }
    
    public boolean isCarIdValid(String carIdStr) {
        if (!isStringNumeric(carIdStr) || carIdStr.length() != 3) {
            return false;
        }
        return true;
    }
    
    public boolean isCategoryValid(String input){
        if (input == null) return false;
        return input.equalsIgnoreCase("New") || input.equalsIgnoreCase("Used");
    }
    
    public int findCar(int id) {    
        int index = -1;
        int size = carList.size();
        
        for (int i = 0; i < size; i++) {
            if (carList.get(i).getCarID() == id) {
                index = i;
                break;
            }
        }
        return index;        
    }
    
    // Car management methods
    public boolean addCar(Car car) {
        if (findCar(car.getCarID()) == -1) {
            carList.add(car);
            return true;
        }
        return false; // Car ID already exists
    }
    
    public Car getCarById(int id) {
        int index = findCar(id);
        if (index != -1) {
            return carList.get(index);
        }
        return null;
    }
    
    public ArrayList<Car> getCarList() {
        return carList;
    }
    
    public String getAllCarsAsString() {
        StringBuilder sb = new StringBuilder();
        int size = carList.size();
        
        if (size == 0) {
            return "No cars registered yet.";
        }
        
        sb.append("===== Car List =====\n\n");
        for (int i = 0; i < size; i++) {
            sb.append("Car #").append(i + 1).append("\n");
            sb.append(carList.get(i).toString()).append("\n");
            sb.append("---------------------\n");
        }
        return sb.toString();
    }
    
    // File I/O methods with better error handling
    public void loadCarsFromFile() {
        File file = new File(DATA_FILE);
        if (!file.exists()) {
            System.out.println("Data file '" + DATA_FILE + "' not found. Starting with empty car list.");
            return;
        }
        
        carList.clear(); // Clear existing data
        
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            int lineNumber = 0;
            int loadedCars = 0;
            
            while ((line = reader.readLine()) != null) {
                lineNumber++;
                line = line.trim();
                
                if (line.isEmpty()) {
                    continue; // Skip empty lines
                }
                
                try {
                    // Expected format: carID,brand,model,year,price,category
                    String[] parts = line.split(",");
                    if (parts.length != 6) {
                        System.err.println("Warning: Invalid format at line " + lineNumber + ": " + line);
                        continue;
                    }
                    
                    int carID = Integer.parseInt(parts[0].trim());
                    String brand = parts[1].trim();
                    String model = parts[2].trim();
                    int year = Integer.parseInt(parts[3].trim());
                    int price = Integer.parseInt(parts[4].trim());
                    String category = parts[5].trim();
                    
                    Car car = new Car(carID, brand, model, year, price, category);
                    carList.add(car);
                    loadedCars++;
                    
                } catch (NumberFormatException e) {
                    System.err.println("Warning: Invalid number format at line " + lineNumber + ": " + line);
                } catch (Exception e) {
                    System.err.println("Warning: Error parsing line " + lineNumber + ": " + line);
                }
            }
            
            System.out.println("Successfully loaded " + loadedCars + " cars from file.");
            
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }
    }
    
    public boolean saveCarsToFile() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(DATA_FILE))) {
            for (Car car : carList) {
                writer.println(car.getCarID() + "," +
                              car.getBrand() + "," +
                              car.getModel() + "," +
                              car.getYear() + "," +
                              car.getPrice() + "," +
                              car.getCategory());
            }
            System.out.println("Successfully saved " + carList.size() + " cars to file.");
            return true;
        } catch (IOException e) {
            System.err.println("Error saving file: " + e.getMessage());
            return false;
        }
    }
    
    public boolean hasData() {
        return !carList.isEmpty();
    }
    
    public int getCarCount() {
        return carList.size();
    }
    
    public String getLatestCarInfo() {
        if (carList.isEmpty()) {
            return "No cars registered yet.";
        }
        Car latestCar = carList.get(carList.size() - 1);
        return "Latest car added:\n" + latestCar.toString();
    }
}