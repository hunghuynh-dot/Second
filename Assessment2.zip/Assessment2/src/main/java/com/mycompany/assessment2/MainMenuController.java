package com.mycompany.assessment2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DialogPane; // For CSS styling of alerts
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

import java.io.*; // Import File
import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.concurrent.atomic.AtomicBoolean; // For the dataLoaded flag

public class MainMenuController implements Initializable {

    @FXML private Button btnAddCar;
    @FXML private Button btnSearchCar;
    @FXML private Button btnViewAllCars;
    @FXML private Button btnSaveExit;
    @FXML private TextArea textAreaDisplay;

    // Static list to hold car data, accessible by other controllers
    private static ArrayList<Car> carList = new ArrayList<>();
    private static final String DATA_FILE = "cars_data.txt"; // Data will be saved in project root

    // Flag to ensure data is loaded from file only once per application session
    private static AtomicBoolean dataLoadedFirstTime = new AtomicBoolean(false);

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Only attempt to load data from file if it hasn't been done yet in this app session
        if (!dataLoadedFirstTime.getAndSet(true)) { // Atomically get current and set to true
            loadDataFromFileOnceOnStartup();
        }

        // Always update the display based on the current state of carList
        updateDisplayBasedOnCarList();
    }

    // This method is intended to be called ONLY ONCE at application startup.
    private void loadDataFromFileOnceOnStartup() {
        File dataFile = new File(DATA_FILE);
        // DEBUG LINE: Print the absolute path where the application is looking for the file
        System.out.println("Initial load attempt from: " + dataFile.getAbsolutePath());

        // We load into a temporary list first. If successful, we replace the static carList.
        // This avoids clearing carList if the file is not found or is empty on startup.
        ArrayList<Car> tempLoadedCars = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(dataFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) {
                    continue; // Skip empty lines
                }
                String[] parts = line.split(",");
                if (parts.length == 6) {
                    try {
                        int carID = Integer.parseInt(parts[0].trim());
                        String brand = parts[1].trim();
                        String model = parts[2].trim();
                        int year = Integer.parseInt(parts[3].trim());
                        int price = Integer.parseInt(parts[4].trim());
                        String category = parts[5].trim();

                        if (!category.equalsIgnoreCase("New") && !category.equalsIgnoreCase("Used")) {
                            System.err.println("Warning: Invalid category '" + category + "' in data file for car ID " + carID + ". Skipping line.");
                            continue;
                        }
                        Car car = new Car(carID, brand, model, year, price, category);
                        tempLoadedCars.add(car);
                    } catch (NumberFormatException nfe) {
                        System.err.println("Warning: Malformed number in data file. Line: '" + line + "'. Error: " + nfe.getMessage() + ". Skipping line.");
                    }
                } else {
                    System.err.println("Warning: Malformed line in data file (incorrect number of parts). Line: '" + line + "'. Skipping line.");
                }
            }

            // If we successfully read some cars, update the static list
            if (!tempLoadedCars.isEmpty()) {
                carList.clear(); // Clear the main static list
                carList.addAll(tempLoadedCars); // Add all loaded cars
                showAlert(Alert.AlertType.INFORMATION, "File Status",
                        "Successfully loaded " + carList.size() + " car records from file.");
            } else if (dataFile.exists()) { // File exists but was empty or all lines were malformed
                 showAlert(Alert.AlertType.INFORMATION, "File Status", "Data file ('" + dataFile.getName() + "') is empty or contains no valid car records. Starting with an empty database.");
            } else {
                // File not found, handled by FileNotFoundException
            }

        } catch (FileNotFoundException e) {
            showAlert(Alert.AlertType.INFORMATION, "File Status", "No existing data file found ('" + dataFile.getName() + "'). Starting with an empty database.");
        } catch (IOException e) {
            showAlert(Alert.AlertType.ERROR, "File Error", "Error reading data file: " + e.getMessage());
            e.printStackTrace();
        }
        // Note: displayWelcomeMessage or displayLatestCarDetails will be called by updateDisplayBasedOnCarList in initialize()
    }

    // Helper method to update the main text area display
    private void updateDisplayBasedOnCarList() {
        if (textAreaDisplay != null) { // Ensure UI component is available
            if (carList.isEmpty()) {
                displayWelcomeMessage();
            } else {
                // You could choose to always show welcome, or always show latest, or a mix
                // For simplicity after load/navigation, let's show welcome which includes the count
                displayWelcomeMessage();
                // Or if you prefer to show the latest car after any successful load:
                // displayLatestCarDetails();
            }
        }
    }

    // Display welcome message
    private void displayWelcomeMessage() {
        if (textAreaDisplay != null) {
            textAreaDisplay.setText("=== Welcome to Car Management System ===\n\n" +
                    "• Click 'Add a new car' to register a new vehicle\n" +
                    "• Click 'Search for a car' to find a specific car by ID\n" +
                    "• Click 'View all cars' to see all registered vehicles\n" +
                    "• Click 'Save and Exit' to save data and close the application\n\n" +
                    "Total cars in database: " + carList.size());
        }
    }

    // Display latest car details
    private void displayLatestCarDetails() {
        if (textAreaDisplay != null) {
            if (!carList.isEmpty()) {
                Car latestCar = carList.get(carList.size() - 1);
                textAreaDisplay.setText("=== Latest Car Added ===\n\n" + latestCar.toString() +
                        "\n\n=== System Status ===\n" +
                        "Total cars in database: " + carList.size() +
                        "\nLast updated: " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")));
            } else {
                displayWelcomeMessage(); // Fallback if list becomes empty
            }
        }
    }

    @FXML
    private void handleAddCar(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("addCar.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Add New Car");
            stage.show();
        } catch (IOException e) {
            showAlert(Alert.AlertType.ERROR, "Navigation Error", "Could not load Add Car scene: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void handleSearchCar(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("searchCar.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Search for Car");
            stage.show();
        } catch (IOException e) {
            showAlert(Alert.AlertType.ERROR, "Navigation Error", "Could not load Search Car scene: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void handleViewAllCars(ActionEvent event) {
        if (textAreaDisplay != null) {
            if (carList.isEmpty()) {
                textAreaDisplay.setText("=== Car Database ===\n\nNo cars found in the database.\n\n" +
                        "Click 'Add a new car' to register your first vehicle.");
            } else {
                StringBuilder display = new StringBuilder();
                display.append("=== All Registered Cars ===\n\n");
                for (int i = 0; i < carList.size(); i++) {
                    display.append("Car #").append(i + 1).append("\n");
                    display.append(carList.get(i).toString());
                    display.append("\n");
                    display.append("-".repeat(50));
                    display.append("\n\n");
                }
                display.append("Total cars: ").append(carList.size());
                textAreaDisplay.setText(display.toString());
            }
        }
    }

    @FXML
    private void handleSaveExit(ActionEvent event) {
        Alert confirmAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmAlert.setTitle("Save and Exit");
        confirmAlert.setHeaderText("Are you sure you want to save and exit?");
        confirmAlert.setContentText("All current data will be saved to file.");

        applyDialogStyling(confirmAlert.getDialogPane()); // Apply CSS

        Optional<ButtonType> result = confirmAlert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            saveCarDataToFile(); // Renamed for clarity
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.close();
        }
    }

    // Renamed for clarity
    private void saveCarDataToFile() {
        File dataFile = new File(DATA_FILE);
        System.out.println("Attempting to save data to: " + dataFile.getAbsolutePath());

        try (PrintWriter writer = new PrintWriter(new FileWriter(dataFile))) {
            for (Car car : carList) {
                writer.println(car.getCarID() + "," + car.getBrand() + "," + car.getModel() + "," +
                        car.getYear() + "," + car.getPrice() + "," + car.getCategory());
            }
            showAlert(Alert.AlertType.INFORMATION, "Save Successful",
                    "Successfully saved " + carList.size() + " car records to file.");
        } catch (IOException e) {
            showAlert(Alert.AlertType.ERROR, "Save Error", "Error saving data to file: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Utility method to show alerts and apply common styling
    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        applyDialogStyling(alert.getDialogPane()); // Apply CSS
        alert.showAndWait();
    }

    // Helper method to apply CSS to dialogs
    private void applyDialogStyling(DialogPane dialogPane) {
        if (dialogPane == null) return;
        URL cssUrl = getClass().getResource("dialog-style.css");
        if (cssUrl != null) {
            dialogPane.getStylesheets().add(cssUrl.toExternalForm());
            // System.out.println("Applied dialog-style.css to a dialog."); // For debugging
        } else {
            // System.err.println("ERROR: Could not find dialog-style.css for a dialog.");
        }
    }

    // Static methods to interact with the carList from other controllers
    public static ArrayList<Car> getCarList() {
        return carList; // Assumes carList is initialized at class level
    }

    public static void addCar(Car car) {
        if (car != null) {
            carList.add(car); // Assumes carList is initialized
        }
    }

    public static int findCar(int carID) {
        // Assumes carList is initialized
        for (int i = 0; i < carList.size(); i++) {
            if (carList.get(i).getCarID() == carID) {
                return i;
            }
        }
        return -1;
    }
}