package com.mycompany.assessment2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class SearchCarController implements Initializable {

    @FXML private TextField txtSearchID;
    @FXML private Button btnSearch;
    @FXML private Button btnClearSearch;
    @FXML private Button btnExitSearch;
    @FXML private TextArea textAreaResult;
    @FXML private Label lblSearchMessage;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Set focus to search field
        txtSearchID.requestFocus();

        // Clear previous messages and results
        lblSearchMessage.setText("");
        lblSearchMessage.setStyle("-fx-text-fill: black;"); // Default message color
        textAreaResult.setText("Enter a Car ID (3 digits) and click 'Search' to find a specific car.\n\n" +
                              "Total cars in database: " + MainMenuController.getCarList().size());
    }

    @FXML
    private void handleSearch(ActionEvent event) {
        // Clear previous messages
        lblSearchMessage.setText("");
        lblSearchMessage.setStyle("-fx-text-fill: red;"); // Default to error color for messages

        String searchIDText = txtSearchID.getText().trim();

        // Validate input
        if (!validateSearchInput(searchIDText)) {
            // Validation method already sets the error message and focuses the text field
            return;
        }

        try {
            int searchID = Integer.parseInt(searchIDText); // Safe to parse after validation

            // Search for the car using the static method from MainMenuController
            int index = MainMenuController.findCar(searchID);

            if (index != -1) {
                // Car found
                ArrayList<Car> carList = MainMenuController.getCarList();
                Car foundCar = carList.get(index);

                StringBuilder result = new StringBuilder();
                result.append("=== SEARCH RESULT ===\n\n");
                result.append("✓ Car Found!\n\n");
                result.append(foundCar.toString()); // Assuming Car.toString() is well-formatted
                result.append("\n\n");
                result.append("=== SEARCH DETAILS ===\n");
                result.append("Searched Car ID: ").append(searchID).append("\n");
                result.append("Position in database: Record #").append(index + 1).append(" of ").append(carList.size());

                textAreaResult.setText(result.toString());

                lblSearchMessage.setStyle("-fx-text-fill: green;");
                lblSearchMessage.setText("Car ID " + searchID + " found successfully!");
                txtSearchID.selectAll(); // Select text for easy new search

            } else {
                // Car not found
                StringBuilder result = new StringBuilder();
                result.append("=== SEARCH RESULT ===\n\n");
                result.append("✗ Car Not Found!\n\n");
                result.append("Searched Car ID: ").append(searchID).append("\n");
                result.append("Status: This Car ID does not exist in the database.\n\n");
                result.append("=== SUGGESTIONS ===\n");
                result.append("• Double-check if the entered Car ID is correct.\n");
                result.append("• Ensure the car has been previously registered.\n");
                result.append("• Use 'View all cars' from the main menu to see all available cars and their IDs.\n\n");
                result.append("Total cars in database currently: ").append(MainMenuController.getCarList().size());

                textAreaResult.setText(result.toString());

                lblSearchMessage.setText("Car ID " + searchID + " not found in the database.");
                txtSearchID.selectAll();
            }
            txtSearchID.requestFocus(); // Keep focus on search field for next search

        } catch (NumberFormatException e) {
            // This specific catch might be redundant if validateSearchInput is thorough.
            lblSearchMessage.setText("Error: Invalid Car ID format!");
            textAreaResult.setText("Search failed due to invalid input format.\n\n" +
                                 "Please enter a valid 3-digit numeric Car ID.");
            txtSearchID.requestFocus();
        } catch (Exception e) {
            // Catch any other unexpected errors
            lblSearchMessage.setText("An unexpected error occurred: " + e.getMessage());
            textAreaResult.setText("An unexpected error occurred during the search operation.");
            e.printStackTrace(); // Log the full error for debugging
        }
    }

    @FXML
    private void handleClearSearch(ActionEvent event) {
        txtSearchID.clear();
        lblSearchMessage.setText("");
        lblSearchMessage.setStyle("-fx-text-fill: black;");
        textAreaResult.setText("Enter a Car ID (3 digits) and click 'Search' to find a specific car.\n\n" +
                              "Total cars in database: " + MainMenuController.getCarList().size());
        txtSearchID.requestFocus();
    }

    @FXML
    private void handleExitSearch(ActionEvent event) {
        try {
            // Use relative path for loading FXML from the same package
            FXMLLoader loader = new FXMLLoader(getClass().getResource("mainMenu.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Car Management System"); // Reset title to main menu title
            stage.show();
        } catch (IOException e) {
            showAlert(Alert.AlertType.ERROR, "Navigation Error", "Could not return to main menu: " + e.getMessage());
            e.printStackTrace(); // Print stack trace for debugging
        }
    }

    private boolean validateSearchInput(String input) {
        // Check if input is empty
        if (input.isEmpty()) {
            lblSearchMessage.setText("Error: Please enter a Car ID to search!");
            textAreaResult.setText("Search cannot be performed with an empty Car ID.\n\n" +
                                 "Please enter a 3-digit numeric Car ID and try again.");
            txtSearchID.requestFocus();
            return false;
        }

        // Check if input is numeric
        if (!isStringNumeric(input)) {
            lblSearchMessage.setText("Error: Car ID must be numeric!");
            textAreaResult.setText("Invalid Car ID format.\n\n" +
                                 "Car ID must contain only numbers (0-9).\n" +
                                 "Example: 101, 205, 300\n\n" +
                                 "Please enter a valid 3-digit numeric Car ID.");
            txtSearchID.selectAll();
            txtSearchID.requestFocus();
            return false;
        }

        // Check if input is 3 digits
        if (input.length() != 3) {
            lblSearchMessage.setText("Error: Car ID must be exactly 3 digits!");
            textAreaResult.setText("Invalid Car ID length.\n\n" +
                                 "Car ID must be exactly 3 digits long.\n" +
                                 "Examples: 123, 456, 789\n\n" +
                                 "Please enter a valid 3-digit numeric Car ID.");
            txtSearchID.selectAll();
            txtSearchID.requestFocus();
            return false;
        }
        lblSearchMessage.setText(""); // Clear message if validation passes before search attempt
        lblSearchMessage.setStyle("-fx-text-fill: black;");
        return true;
    }

    // Check if string is numeric
    private boolean isStringNumeric(String str) {
        if (str == null || str.isEmpty()) { // str can be null, check explicitly
            return false;
        }
        for (char c : str.toCharArray()) { // More efficient way to iterate chars
            if (!Character.isDigit(c)) {
                return false;
            }
        }
        return true;
    }

    // Utility method to show alerts (already present, good)
    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}