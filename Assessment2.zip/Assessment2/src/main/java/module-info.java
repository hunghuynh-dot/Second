// NEW, simpler module-info.java content
module com.mycompany.assessment2 {
    requires javafx.controls;
    requires javafx.fxml;

    // This now covers both controllers and FXML files in this package
    opens com.mycompany.assessment2 to javafx.fxml;

    exports com.mycompany.assessment2;
}